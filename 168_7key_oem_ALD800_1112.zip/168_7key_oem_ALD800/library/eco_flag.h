#ifndef __ECO_FLAG__
#define	__ECO_FLAG__

#include "type.h"


#define ECO1_FLAG	0xFFFF
#define ECO2_FLAG	0xFEFF
#define ECO3_FLAG	0xFDFF
#define ECO6_FLAG	0xDDFF
#define ECOB_FLAG	0x00FF


WORD GetECOFlag(VOID);


#endif
