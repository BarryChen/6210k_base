#ifndef __AUDIO_STREAM_H__
#define __AUDIO_STREAM_H__

VOID AudioStreamInit(VOID);
VOID AudioStreamProcess(VOID);


#endif
