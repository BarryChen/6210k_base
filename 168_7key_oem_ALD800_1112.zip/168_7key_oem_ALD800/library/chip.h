#ifndef __CHIP_H__
#define __CHIP_H__


VOID ChipInit(VOID);


#endif
