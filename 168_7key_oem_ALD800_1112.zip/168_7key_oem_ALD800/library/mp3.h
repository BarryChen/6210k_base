#ifndef __MP3_H__
#define __MP3_H__


// ParserMp3
BOOL ParserMp3(VOID);

#endif
