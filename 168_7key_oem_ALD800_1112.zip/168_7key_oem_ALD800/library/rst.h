#ifndef __RST_H__
#define	__RST_H__


VOID WatchDogEn(VOID);
VOID WatchDogDis(VOID);
VOID RstDecd(VOID);
VOID RstCard(VOID);
VOID RstDac(VOID);
VOID RstUsb(VOID);
VOID RstAdc(VOID);
VOID RstCts(VOID);
VOID RstIr(VOID);

#endif

