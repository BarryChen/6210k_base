#ifndef __INTERRUPT_H__
#define __INTERRUPT_H__

// Interrupts control initialize operation.
VOID ExInt1Init(VOID);
VOID Timer1Init(VOID);

#endif
