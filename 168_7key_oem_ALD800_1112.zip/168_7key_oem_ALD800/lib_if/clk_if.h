#ifndef __CLK_IF_H__
#define __CLK_IF_H__


// System clock divider setting.
VOID SysClkDivSet(BYTE ClkDivRate);

// System clock divider clear.
VOID SysClkDivClr(VOID);


#endif
