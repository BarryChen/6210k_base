#ifndef __TOUCH_KEY_H__
#define __TOUCH_KEY_H__

#include "type.h"

VOID TouchKeyScanInit();

MESSAGE TouchKeyEventGet(VOID);

#endif 