#ifndef __DEVCTRL_H__
#define __DEVCTRL_H__


VOID DevCtrlInit(VOID);
VOID DevStateCtrl(VOID);
VOID StandbyStateCtrl(VOID);

#endif
