#ifndef __CARD_READER_CTRL_H__
#define __CARD_READER_CTRL_H__

// mass-storage device initial
VOID DeviceStorCtrlInit(VOID);

// mass-storage device initial
VOID DeviceStorCtrlEnd(VOID);

// mass-storage device process
VOID DeviceStorStateCtrl(VOID);

#endif
