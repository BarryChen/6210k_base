#ifndef __LINEIN_CTRL_H__
#define __LINEIN_CTRL_H__


VOID LineInCtrlInit(VOID);

VOID LineinIODeinit(VOID);

// line-in mode state control.
VOID LineInStateCtrl(VOID);


#endif
