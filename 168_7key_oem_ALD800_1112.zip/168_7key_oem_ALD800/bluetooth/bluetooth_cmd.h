#ifndef _BLUETOOTH_CMD_H_
#define _BLUETOOTH_CMD_H_
#if 0
VOID BluetoothCmdInit();
//VOID BluetoothRefreshStatus();
VOID BluetoothCmdPlay();
VOID BluetoothCmdNext();
VOID BluetoothCmdPrev();
VOID BluetoothCmdVolUp();
VOID BluetoothCmdVowDown();
VOID BluetoothCmdReconnect();
VOID BluetoothCmdAnswerCall();
VOID BluetoothCmdRejectCall();
VOID BluetoothCmdHungUpCall();
VOID BluetoothCmdRedial();
VOID BluetoothCmdDisconnect();

VOID OnDataReceived();
#endif
#endif
