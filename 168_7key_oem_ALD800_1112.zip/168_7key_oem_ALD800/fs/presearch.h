#ifndef __PRESEARCH_H__
#define __PRESEARCH_H__



BOOL FSInit(BYTE DeviceID);

#endif
